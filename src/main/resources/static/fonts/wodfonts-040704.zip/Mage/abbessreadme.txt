Font Name: 
				Abbess Regular
File Name: 
				Abbess__.ttf
Used For: 
				Mage: The Ascension headers, Toreador headers
Problems: 
				Very limited character set.  Letters, numbers, and essential punctuation, but that's it.
Bonuses:
				I have remapped the original version of this font so that the single and double quotes match the keyboard.
				Check the website below for updates to this font (adding more characters to the set, etc.)

===========================================
|Info provided by:                        |
|				Deke Martin                       |
|				glasswalker@naxs.net              |
|				http://members.aol.com/dekemartin | 
|                                         |
|				21 October, 1999                  |
===========================================