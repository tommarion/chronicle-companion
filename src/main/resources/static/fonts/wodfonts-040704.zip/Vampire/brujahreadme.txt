Font Name: 
				Stucco 555 (True Type)

File Name: 
				Stucco.ttf

Used For: 
				Brujah headers in the Clan Book, as well as the core rules

Problems: 
				Single and double quotes are not mapped to the proper keys.
				They are in the set, but you must use the character map to find where they reside.
				This might be corrected in the future.

Bonuses:
				The set does contain the full set of alternate charcters for a Western set.

Info provided by:
				Deke Martin
				glasswalker@naxs.net
				http://members.aol.com/dekemartin

2:28 AM 10/21/1999